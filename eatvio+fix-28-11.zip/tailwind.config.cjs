export default {
  content: [
    "./src/**/*.{html, scss}"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

