export { popup } from './popup.js';
export { initTooltips } from './tooltip.js';
export { maxlength } from "./maxlength.js";
export { select } from "./select.js";
export { checking } from "./checking.js";
export { slider } from "./slider.js";
export { burger } from './burger.js';
export { fixedTable } from './fixedTable.js';
export { slide } from "./slideToggle.js";
export { spollers } from './spoller.js';
export { tabs } from './tabs.js';
// export { inputFiles } from './files.js';




